# NorteAgro Layout de plantas - versão 0.29.0

> **0.29.0**: o modo IA foi retirado (área "Criar modelo com IA", configurações de IA e Ollama). O município é achado sozinho pela área do imóvel.

Plugin do QGIS que monta a **Planta de Uso do Solo** e a **Planta de Passivos e Regularização Ambiental** da Norte Agro a partir de modelos, lendo:

- a planilha do **Quadro de Áreas** gerada pelo plugin "Norte Agro - Uso do Solo";
- o **recibo de inscrição no CAR** e a **certidão de matrícula** em PDF (Propriedade, Proprietário, CAR, Município, Matrícula);
- as camadas do projeto aberto (nomes da legenda no padrão do escritório).



---

## 1. Instalar no Windows

1. Baixe `NorteAgro_Layout_IA_QGIS_v0_9_0.zip` (não descompacte).
2. No QGIS: **Complementos > Gerenciar e instalar complementos > Instalar a partir do ZIP**.
3. Escolha o arquivo `.zip` e clique em **Instalar complemento**.
4. Abra pelo menu **Complementos > NorteAgro > Layout de plantas (Uso do Solo, Passivos)** ou pelo ícone na barra.

Requisitos: QGIS 3.40 LTR ou 3.44 (testado no 3.44.10). Não é preciso instalar nada no Python do QGIS.

Para atualizar, repita os passos com o ZIP novo (o QGIS substitui a versão anterior).

---

## 2. Uso diário - gerar a planta

![Aba Planta - topo](docs/1_planta_topo.png)

1. **Modelo** - escolha *Planta de Uso do Solo* ou *Planta de Passivos* e a folha (A4, A3, A2 ou A1).
2. **Documentos do imóvel** - clique em *Adicionar PDF...*, escolha o recibo do CAR e/ou a matrícula e clique em **Ler documentos**. Os campos do quadro 3 são preenchidos. Campos em amarelo foram lidos com menos certeza: confira.
   - Município vem do código IBGE dentro do número do CAR (mais seguro que o texto).
   - Com vários proprietários, o plugin sugere "PRIMEIRO NOME e outros"; a lista aparece na seta do campo.
   - Matrícula digitalizada (só imagem) não tem texto: o plugin avisa. Digite os dados ou instale o OCR opcional (seção 5).
3. **Dados do imóvel** - confira Propriedade, Proprietário, CAR, Matrícula (só sai na planta se preenchida), Município e Estado.
4. **Dados de projeto** - **Elaboração** (seu nome; o plugin lembra os últimos usados e pergunta se estiver vazio), **Data** (hoje por padrão) e **Fonte** ("Google Earth, SICAR" por padrão; use **+ fonte** para acrescentar outras).

![Aba Planta - planilha](docs/2_planta_meio.png)

5. **Planilha de áreas** - escolha o `.xlsx` gerado pelo plugin "Norte Agro - Uso do Solo". O plugin lê só a aba **Quadro de Áreas** e pega os quadros que o modelo usa:
   - Uso do Solo: Áreas Remanescentes, Área de Preservação Permanente, Área Hidrográfica, Áreas Totais do Imóvel;
   - Passivos: Passivos ambientais, Área suprimida antes de 2019, Área suprimida após 2019.
   O total de cada quadro é recalculado pela soma das linhas; se divergir do total gravado na planilha, aparece aviso. Hectares com vírgula e 4 casas (ajustável).

![Aba Planta - mapas](docs/3_planta_mapas.png)

6. **Mapas** - para cada mapa do modelo: camadas, SRC e enquadramento próprios.
   - *Automático (SIRGAS 2000 / UTM do fuso do imóvel)* calcula o fuso pela posição do imóvel.
   - Enquadramento: ajustar à camada (com margem), extensão manual (desenhar no mapa ou usar a vista atual), localização do município inteiro, do estado ou do Brasil, tema do projeto, ou igual ao outro mapa (planta de Passivos).
   - O mapa de localização usa a camada de municípios do projeto (ou a malha de Goiás do IBGE que acompanha o plugin) com estilo próprio do mapa: o município em verde, vizinhos em cinza com nome. A camada do projeto **não** é alterada.
   - A ordem de desenho segue o painel de camadas; imagens e mapas de fundo ficam sempre embaixo.
7. Clique em **Gerar planta**. O layout é criado no projeto e abre no editor de layout.

Resultado (dados fictícios dos testes):

![Planta de Uso do Solo](docs/previa_uso_solo_A3_ficticio.png)

![Planta de Passivos](docs/previa_passivos_A3_ficticio.png)

### O que é automático na planta

- Textos variáveis são **variáveis do projeto** (`@na_imovel`, `@na_proprietario`, `@na_car`, `@na_municipio`, `@na_elaboracao`, `@na_data`, `@na_fonte`, `@na_responsavel`, `@na_crea`...). Trocou um dado em *Projeto > Propriedades > Variáveis*? O layout atualiza sozinho.
- **Parâmetros cartográficos** (projeção, datum, meridiano central, fuso) são calculados do SRC do mapa. Isso corrige o erro dos modelos antigos do Drive, que traziam "Meridiano Central: 45°" com "Fuso: 22 Sul" (o certo é 51° W).
- **Escala** em "Dados de projeto" acompanha a escala real do mapa; **Folha** vem do tamanho da página.
- **Responsável técnico** sempre do perfil salvo em Configurações (padrão: Ramon Coelho Souza Gomes, Engenheiro Agrônomo, CREA 101344513-9/D-GO), com a imagem da assinatura se ela for informada.
- Legenda só com as camadas do mapa, sem mapas de fundo, com os nomes do Guia de Padronização (tabela `dados/correspondencia_camadas.csv`, editável).
- Se a legenda não couber no espaço, a fonte é reduzida aos poucos (até 60%) e aparece aviso.

### Botões extras

- **Salvar layout como modelo** - grava na biblioteca (QPT + miniatura + modelo.json) uma cópia **sem** as camadas, caminhos e áreas do imóvel atual. Bloqueia se houver CPF/CNPJ/CREA/e-mail literal nos textos.
- **Exportar pacote (QPT + prévia)** - grava `layout.qpt`, `pre_visualizacao.png`, `recursos/`, `COMO_ABRIR.txt` e um `.zip`.

---

## 4. Configurações

![Configurações](docs/5_configuracoes.png)

- **Responsável técnico** e imagem da assinatura (no Drive: `...\QGIS\LAYOUT\ASSINATURA - RAMON 01.png`).
- **Pasta da biblioteca** de modelos (padrão: perfil do QGIS `\norteagro_modelos`; pode ser pasta de rede ou do Drive compartilhado).
- **Tabela de nomes (CSV)**: *Copiar tabela para a biblioteca* cria uma cópia editável (ex.: acrescentar uma camada nova do escritório). Colunas: `arquivo;nome_legenda;apelidos;papel;grupo` (apelidos separados por `|`).

## 5. Ambiente de suporte (opcional)

Só para PDF que o GDAL do QGIS não abrir e para OCR de documentos digitalizados. Fica separado do Python do QGIS.

- `support\Preparar_PDF_Windows.cmd` - cria `%USERPROFILE%\.norteagro_layout_ia\venv` com PyMuPDF e Pillow.
- `support\Instalar_OCR_Windows.cmd` - o mesmo, com o OCR (rapidocr).
- Depois informe em Configurações > **Python de suporte** o caminho mostrado no fim do script.

Os scripts avisam se o Python não estiver instalado, se a versão for incompatível (use 3.10 a 3.13) ou se o download falhar (internet ou proxy).

---

## 6. Problemas comuns

| Mensagem | O que fazer |
| --- | --- |
| Não encontrei os quadros de áreas | Use a planilha gerada pelo "Norte Agro - Uso do Solo" (aba Quadro de Áreas). |
| A linha 'X' é uma fórmula sem resultado salvo | Abra a planilha no Excel, salve e escolha de novo. |
| Município 'X' não encontrado na camada | Confira o nome do município em Dados do imóvel. |
| ... parece digitalizado (só imagem) | Digite os dados ou use o OCR do ambiente de suporte. |
| Exportação bloqueada: há textos com CPF/CNPJ/CREA | Confirme os itens da tabela de dados pessoais. |

Detalhes de erros ficam no painel **Mensagens de log**, aba **NorteAgro Layout**.

---

## 7. Testes

Fora do QGIS (Python 3.10+):

```
cd norteagro_layout_ia\testes
python -m unittest test_nucleo test_postprocess test_documentos
```

Dentro do QGIS (Console Python), com dados fictícios e projeto separado (não mexe no projeto aberto):

```
exec(open(r"<pasta do plugin>\testes\qgis_integracao.py", encoding="utf-8").read())
```

