# Validação - definição de pronto da versão 1.0

Conclusão: **a definição de pronto NÃO foi cumprida inteira**. Por isso o pacote sai como **0.9.0, experimental**, conforme o comando. O que falta está marcado abaixo e em `PENDENCIAS.md`.

Ambiente das evidências: QGIS 3.44.10-Solothurn, Windows (computador do escritório), em 22/10/2026. Testes sem QGIS: Python 3.13.

| # | Item | Situação | Evidência |
|---|---|---|---|
| 1 | Instala por ZIP no QGIS 3.40 e 3.44 no Windows, sem erro no log | **Parcial**: 3.44 cumprido; 3.40 **NÃO TESTADO** | Instalado pela rotina oficial "Instalar a partir do ZIP" (`pyplugin_installer.installFromZipFile`) no 3.44.10; log com "Complemento instalado corretamente" e nenhum erro. Não havia QGIS 3.40 disponível. As APIs usadas existem desde o 3.30 (formato de texto da legenda) ou antes. |
| 2 | Modo "Modelo Norte Agro" gera Planta de Uso do Solo completa sem IA | **Cumprido** | Integração: Uso do Solo A3 e A2 e Passivos A3 em menos de 1 s cada (dados fictícios). Dados reais (projeto Fazenda Cristalina + planilha gerada pelo plugin Uso do Solo): 3,6 s pela API e 2,8 s pelo botão "Gerar planta". Prévias conferidas visualmente. |
| 3 | 5 referências por IA com no máximo 5 correções manuais cada, no benchmark | **NÃO TESTADO** | O Ollama não está instalado no computador de teste e não há chave de API. `benchmark.csv` lista as referências planejadas como NÃO TESTADO. A cadeia (prompt, contrato, retry de JSON, pós-processamento, proteção, construção) está coberta por testes com respostas simuladas e pelo exemplo manual. |
| 4 | Nenhum nome, CREA, CPF, CNPJ ou matrícula da referência no QPT sem confirmação explícita | **Cumprido nos casos testados** | Integração: QPT sem "João Fictício", "123456789-0", "Fulano Fictício", "Maria Exemplo", "12.345", "15/08/2026", "Fazenda Modelo"; exportação bloqueada com item pendente e com texto suspeito. Limite conhecido: nome solto sem nenhuma palavra-chave e fora do bloco de RT (ex.: um crédito "Fulano de Tal" isolado) não é detectável automaticamente; a revisão mostra todos os textos. |
| 5 | Mapas com camadas, SRC e extensão independentes; QPT reaberto em outro projeto mantém | **Cumprido** | Integração: 3 mapas (município, estado, Brasil) com extensões e camadas diferentes; QPT reaberto em projeto novo com as mesmas fontes: camadas, SRC, extensões e o estilo do destaque iguais. |
| 6 | Todos os testes automatizados passam e este documento registra cada passo | **Cumprido** | 53/53 sem QGIS; 40/40 no QGIS 3.44 (`testes/resultado_integracao_windows_3_44.json`). |

## Aceites por fase

| Fase | Aceite pedido | Situação |
|---|---|---|
| 1 | 3 mapas, QPT reaberto em projeto novo, teste automatizado | Cumprido (`t_fase1_tres_mapas`, `t_ordem_camadas`) |
| 2 | Reprocessar a resposta salva do primeiro teste | **Cumprido com ressalva**: resposta original indisponível; usada reconstrução fiel à descrição (`teste1_reconstruido.json`). Um teste por regra: cumprido. |
| 3 | Referência com nome e CREA fictícios gera layout sem esses textos | Cumprido (unitário + integração + exemplo com caixas separadas) |
| 4 | Tabela nos 4 blocos + importação com planilha de exemplo | Cumprido (`examples/quadro_areas_exemplo.xlsx` e `.csv`) + planilha real |
| 5 | benchmark.csv com 2 backends ou 2 modelos do Ollama | **NÃO TESTADO** (sem Ollama e sem chave) |
| 6 | Planta completa pelo modelo de fábrica em menos de 1 minuto, sem IA | Cumprido |
| 7 | Verificações no Windows | Ver tabela abaixo |

## Verificações da Fase 7 no Windows

| Verificação | Situação |
|---|---|
| Instalação por ZIP | Testado (3.44.10) |
| Preparar_PDF_Windows.cmd | **NÃO TESTADO** (não foi executado para não instalar Python/pacotes no computador sem pedir; o plugin lê PDF pelo GDAL do QGIS e não depende dele) |
| Instalar_OCR_Windows.cmd | **NÃO TESTADO** (mesmo motivo) |
| Análise de imagem por IA | **NÃO TESTADO** (sem Ollama) |
| PDF com várias páginas | Testado (GDAL do QGIS, página 2 de 2; página inexistente bloqueada) |
| Foto inclinada com retificação | Testado (foto simulada em perspectiva; diferença média 3/255) |
| Modo Modelo Norte Agro | Testado (fictício e real) |
| Exportação e reabertura do QPT em outro projeto | Testado |
| Caminhos com espaço e acento | Testado ("Fazenda São José teste") |
| Leitura de recibo do CAR e matrícula | Testado com documentos reais (SIGCAR e duas certidões); matrícula digitalizada reconhecida como "só imagem" |
| Janela do plugin | Testado: abrir, ler documentos, escolher planilha, "+ fonte", gerar planta, abrir exemplo de IA, decisões de identidade, gerar layout por referência |

## Revisão independente de código

Achados altos (todos corrigidos e com teste): decisão "manter" depois "marcador" não restaurava o marcador; `proposta_ia.json` e resposta bruta iam para o pacote com textos originais; rótulo e valor em linhas/células separadas escapavam da proteção.

Médios corrigidos: recorte de imagem da referência embutido sem confirmação; varredura final não pegava "CREA-GO 12345"; "Salvar como modelo" sem checagem e levando camadas/caminhos e áreas do cliente para a biblioteca; mesmo layout compartilhado entre as abas; tempo limite de rede global sem controle de concorrência; tempo esgotado mostrado como "Ollama não encontrado"; `gdal.UseExceptions()` global e caminho alternativo de PDF inalcançável.

Médio **não corrigido por decisão**: o QPT do **pacote do imóvel** guarda a fonte das camadas (caminho da pasta do cliente). Isso é necessário para reabrir o layout com as camadas; o QPT da **biblioteca** não leva esses caminhos.

Baixos corrigidos: janelas modais desnecessárias (cancelamento, falha de download, aviso ao aplicar), exceções não tratadas (planilha corrompida, OCR, modelo.json, serviço inválido), margem do mapa de localização, remoção de elemento sem remover os itens de identidade, textos em inglês. Baixo pendente: ao desinstalar com a ferramenta "desenhar extensão" ativa, a ferramenta anterior do mapa não é restaurada.
