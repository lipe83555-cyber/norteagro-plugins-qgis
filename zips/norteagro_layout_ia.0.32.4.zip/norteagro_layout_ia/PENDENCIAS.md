# Pendências (sem suavizar)

1. **IA não testada de ponta a ponta.** Nenhuma análise real foi feita nesta versão: Ollama não instalado e sem chave de API. Não há medida de qualidade da IA nem benchmark. Para fazer: instalar o Ollama, baixar `qwen3-vl:4b-instruct` e um segundo modelo, rodar `testes/benchmark.py` com as 5 referências e preencher a coluna "correcoes_manuais".
2. **Definição de pronto item 3 não cumprida** (5 referências com no máximo 5 correções cada). É o principal motivo de a versão não ser 1.0.
3. **QGIS 3.40 LTR não testado.** Só o 3.44.10.
4. **Scripts `.cmd` do ambiente de suporte não executados** (PDF alternativo e OCR). O OCR de matrícula digitalizada depende deles e não foi testado.
5. **Código da v0.1.1 não foi usado** (arquivo indisponível). O comportamento da v0.1.1 que não estava descrito no documento do projeto pode ter se perdido. Se o ZIP aparecer, vale comparar.
6. **Aceite da Fase 2 feito com reconstrução** da resposta do primeiro teste, não com a resposta original.
7. **Proteção de identidade tem limite**: nome isolado sem palavra-chave, fora do bloco de RT, não é detectado. A revisão humana continua necessária no modo IA.
8. **Chave de API no cofre do QGIS não testada** (exige a senha mestra).
9. **Quadros da planilha atual x plantas antigas**: a planilha do plugin Uso do Solo não soma a APP Preservada em "Áreas Remanescentes" e separa "Área sem classificação"; nas plantas antigas era diferente. O plugin de layout reproduz a planilha. Confirmar com o escritório qual é o padrão correto.
10. **Casas decimais**: o comando pede 4; as plantas reais usam 2. Padrão ficou 4, ajustável na tela.
11. **Nome na legenda do imóvel**: o Guia de Padronização usa "Área Total do Imóvel"; plantas antigas usam "Área do imóvel". Segue o Guia; editar `dados/correspondencia_camadas.csv` se o escritório preferir o outro.
12. Coordenadas da moldura em UTM (metros). A planta da Cristalina usava graus (DMS). Hoje a grade segue o SRC do mapa; não há opção na tela para forçar graus.
13. Ferramenta "desenhar extensão" não é restaurada se o plugin for desinstalado com ela ativa (baixo).
14. Plugin "Norte Agro Layout" 1.6.0 já instalado no computador faz parte do mesmo trabalho (biblioteca de modelos e dados do imóvel). Vale decidir se os dois continuam separados ou se juntam.
