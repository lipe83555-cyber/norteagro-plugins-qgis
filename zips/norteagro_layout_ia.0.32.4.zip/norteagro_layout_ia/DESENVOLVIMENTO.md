# Registro de desenvolvimento - v0.1.1 para v0.9.0

Data: 22/10/2026. Ambiente de teste: QGIS 3.44.10 (Windows 10/11 x64, Python 3.12.13, Qt 5.15.13) no computador do escritório, via plugin QGIS MCP; testes sem QGIS em Python 3.13 (Linux).

## Ponto de partida (desvio do comando)

O comando pede para evoluir o código da v0.1.1 sem reescrever. **O arquivo `NorteAgro_Layout_IA_QGIS_v0_1_1.zip` não estava disponível**: não veio anexado, não está na pasta Downloads e o documento do projeto só tem um link do ChatGPT, inacessível daqui. Por isso o código foi **reconstruído** seguindo a estrutura e o contrato descritos em `Projeto_NorteAgro_Layout_IA.md` (core/, ui/, builder.py, support/, testes/, examples/, assets/; contrato com `page` em mm, `elements` com `x, y, w, h` em fração da página, tipos `map, label, legend, scale, north, shape, line, table, picture`, vínculos `map_id`, até 250 itens). Campos novos são opcionais (compatíveis). As evidências originais de `validacao_ia/` também não estavam disponíveis.

Materiais reais usados: Planta de Uso do Solo - Fazenda Cristalina (PDF A2), plantas São Joaquim (Uso do Solo e Passivos), modelos `USO DO SOLO - ATUALIZADO` (A1-A4) do Drive, planilha `QUADRO_DE_AREAS` e o código do plugin "Norte Agro - Uso do Solo" v3.9.12 (formato da planilha e catálogo de nomes), recibos do CAR (SIGCAR) e certidões de matrícula da pasta Downloads (só como entrada de teste; não estão no pacote).

Pedidos feitos durante o trabalho e incluídos: campo para escolher a planilha e preencher os quadros nas posições do modelo; leitura de matrícula/recibo do CAR; Elaboração perguntada ao usuário; Data; Fonte com "+"; os dois modelos (Uso do Solo e Passivos); teste usando o plugin Uso do Solo para gerar a planilha real.

As fases não foram executadas estritamente uma de cada vez: o núcleo sem QGIS das Fases 2 a 5 foi escrito e testado primeiro, e as partes com QGIS (Fases 1, 4 e 6) foram testadas juntas quando o QGIS ficou disponível. Os resultados abaixo são das execuções registradas.

---

## Fase 1 - Mapas independentes

O que mudou:
- `builder.configurar_mapa`: camadas próprias (`setLayers`, `setKeepLayerSet(True)`, `setKeepLayerStyles(True)` + `storeCurrentLayerStyles`), SRC próprio ("automático" = SIRGAS 2000/UTM do fuso do imóvel), extensão própria e tema (`setFollowVisibilityPreset`).
- Enquadramentos: camada + margem, manual (desenhar com `QgsMapToolExtent` ou vista atual), município inteiro, estado, Brasil, tema, todas as camadas, igual a outro mapa.
- Localização: o destaque do município é **estilo do item de mapa** (layer style override com regra), não camada nova nem alteração da camada do projeto; sobrevive à reabertura do QPT. Malha de Goiás do IBGE simplificada embutida (`dados/go_municipios_ibge_simplificado.gpkg`) para projetos sem camada de municípios.
- Legenda com `setLinkedMap` e `setLegendFilterByMapEnabled`; escala e norte com `setLinkedMap`; `setNorthMode` com padrão Norte verdadeiro.
- Ordem de desenho = ordem do painel; imagens/mapas de fundo sempre embaixo.
- Camadas regionais (estado, país, malha municipal) excluídas do mapa principal por tamanho (mais de 400 vezes a área do imóvel).
- Painel na interface (`ui/painel_mapa.py`) com checklist de camadas, SRC, enquadramento, margem, tema, camada de municípios e grade.

Testes (QGIS 3.44.10 Windows, `testes/qgis_integracao.py`): 3 mapas (município, estado, Brasil) com extensões e camadas diferentes; QPT reaberto em projeto novo mantém camadas, SRC, extensões e o estilo do destaque; ordem com fundo embaixo. **Passaram.**

Falhas encontradas e corrigidas nesta fase:
1. Primeira versão criava camadas de apoio para a localização; no QPT reaberto o mapa caía na camada original. Trocado por estilo do item. 
2. Prévia mostrou a camada de estado cobrindo o mapa principal. Criada a exclusão por tamanho.
3. Prévia real da planta de Passivos mostrou o Google por cima das camadas (ordem das camadas informada). Criada a ordenação pelo painel + teste.

## Fase 2 - Pós-processamento determinístico

`core/postprocess.py`, entre validação e revisão, registrando cada correção em `conferencia.json` (regra, elemento, antes, depois):
R1 fusão de tabelas sobrepostas (> 50%) e remoção de tabelas sem texto; R2 forma alongada (w/h > 6) perto de texto de escala vira escala vinculada; R3 imagem com proporção de mapa perto de legenda/norte/moldura marcada "provável mapa" (sem converter; botão "Converter em mapa"); R4 alerta de sobreposição > 30% (exceto norte/escala/legenda dentro do mapa e itens dentro de moldura); R5 vínculo ao mapa mais próximo + marca de revisão; R6 recorte aos limites da página; R7 duplicatas (IoU > 0,8).
Extra (R8): meridiano, fuso, datum, folha e escala numérica copiados da referência viram campos automáticos.

Testes: um por regra em `testes/test_postprocess.py` (12) + aceite. **Passaram.**

Aceite: como a resposta salva do primeiro teste não estava disponível, foi usada uma **reconstrução** (`testes/fixtures/teste1_reconstruido.json`) com os 25 elementos e os problemas descritos no documento do projeto (8 tabelas vazias sobrepostas, barra como forma, recorte de localização sobre a legenda). Resultado: sobra 1 tabela, a barra vira escala vinculada ao mapa principal e o recorte fica marcado como provável mapa, com alerta de sobreposição. Não é o reprocessamento da resposta original.

## Fase 3 - Identidade e marcadores dinâmicos

- `core/identidade.py`: CREA, CAU, CPF, CNPJ, "Responsável Técnico", "Elaboração", "Eng.", "Agrônomo", "Proprietário", "Matrícula", CAR, datas, e-mails e telefones viram marcadores `[% @na_... %]`. Também quando o rótulo está numa linha/célula e o valor na seguinte, e quando o nome do RT está em caixa de texto separada do título (mesma moldura ou logo abaixo).
- Recortes de imagem da referência (que podem ser assinatura/carimbo/logo de terceiro) ficam fora por padrão.
- Variáveis de projeto `@na_imovel, @na_municipio, @na_uf, @na_proprietario, @na_documento, @na_matricula, @na_car, @na_fonte, @na_responsavel, @na_rt_titulo, @na_crea, @na_empresa, @na_elaboracao, @na_data` (`QgsExpressionContextUtils.setProjectVariable`); parâmetros cartográficos como variáveis de layout.
- RT só do perfil em QgsSettings (padrão do comando); Elaboração separada e com histórico.
- Exportação e "Salvar como modelo" bloqueados com item pendente ou com CPF/CNPJ/CREA/e-mail literal no layout; o pacote nunca leva os textos originais da referência.

Testes: unitários (identidade, 12) e integração (QPT sem nome/CREA/matrícula/data de terceiro, marcadores presentes, bloqueio). **Passaram.**

Falhas encontradas e corrigidas: (1) teste da janela mostrou o nome do RT de terceiro **no QPT** quando título e nome estão em caixas separadas - corrigido e coberto por teste; (2) a revisão independente apontou que voltar de "manter" para "marcador" não restaurava o marcador, que rótulo e valor em linhas/células separadas escapavam e que `proposta_ia.json`/resposta bruta iam para o pacote - corrigidos e cobertos por testes.

## Fase 4 - Tabela de áreas

- Removido qualquer cálculo de área neste plugin.
- `core/planilha_areas.py`: leitor de `.xlsx` só com a biblioteca padrão (zipfile + xml) e de `.csv`; acha os quadros (título, "Descrição | Hectares", linhas, "Total") na aba "Quadro de Áreas"; total recalculado; avisos para total divergente, fórmula sem valor salvo e fechamento com a Área Total do Imóvel.
- Tabelas nativas `QgsLayoutItemManualTable` (uma por quadro + título), "Descrição | Hectares" como primeira linha, Total em negrito, hectares com vírgula e 4 casas (ajustável), sem tabelas extras. Hidrografia vira "Área Curso D'Água"; cacimbas/barramentos uma linha cada.
- Modelo de Passivos usa os quadros Passivos ambientais / Área suprimida antes de 2019 / após 2019.
- Exemplos fictícios: `examples/quadro_areas_exemplo.xlsx` e `.csv`.

Testes: unitários com o exemplo e com a planilha real gerada; integração (4 tabelas, conteúdo, sem planilha = campos para preencher, moldura comporta todas as linhas). **Passaram.**

Falhas encontradas e corrigidas: (1) prévia com tabelas vazias - o QGIS calcula a altura da tabela pela moldura, que ficou com 5 mm; (2) depois, linha Total sumindo - o QGIS só desenha linha que cabe inteira e faltava 0,1 mm. Alturas fixadas por linha + folga, e teste novo da altura.

Teste com dados reais: planilha gerada pelo plugin "Norte Agro - Uso do Solo" sobre o projeto da Fazenda Cristalina (3,2 s). Valores na planta: Área Hidrográfica 7,26 / 1,35 / 8,61 e Áreas Totais 3856,65 / 893,92 / 4750,57, iguais à planta original. APP e Remanescentes diferem da planta antiga porque a planilha atual separa 0,18 ha "sem classificação" e não soma a APP Preservada nas Remanescentes (comportamento do outro plugin, reproduzido fielmente).

## Fase 5 - Backends de IA e benchmark

- `core/backends/` com interface comum: `ollama` (padrão, só endereço local, `qwen3-vl:4b-instruct`, lista por `/api/tags`, aviso para variante thinking, `think: false` com repetição sem o campo em versões antigas), `anthropic` e `openai` (desativados por padrão, aviso "A imagem será enviada a um serviço externo", chave no `QgsApplication.authManager()`).
- Mesmo prompt, contrato, validador, pós-processamento e proteção para todos (`core/analise.py`); nova tentativa automática pedindo só a correção do JSON.
- Rede por `QgsNetworkAccessManager` (`core/transporte.py`) dentro de `QgsTask`, com cancelamento, tempo limite configurável e status distintos para tempo esgotado/cancelado.
- `testes/benchmark.py` gera `benchmark.csv` com as colunas pedidas.

Testes: unitários com respostas simuladas (fluxo completo, retry de JSON, `think`, endereço não local, sem conexão, tempo esgotado, mesmo contrato nos 3 backends, sem chave, cancelamento). No QGIS: mensagem "Ollama não encontrado em 127.0.0.1:11434 - abra o Ollama e clique em Testar conexão." conferida. **Passaram.**

**NÃO TESTADO**: análise real por IA e benchmark. O Ollama não está instalado no computador de teste e não há chave de API disponível. `benchmark.csv` traz as referências planejadas marcadas NÃO TESTADO. Guardar chave no cofre do QGIS também não foi testado (pede a senha mestra, interação do usuário).

## Fase 6 - Modelo Norte Agro e biblioteca

- `modelos.py`: modelos de fábrica **Planta de Uso do Solo** (a partir da Cristalina e dos modelos do Drive) e **Planta de Passivos** (São Joaquim), descritos em mm de A3 e escalados para A4, A2 e A1. Mapa principal com coordenadas na moldura, localização do município, 4 quadros, legenda, escala gráfica e numérica (em "Dados de projeto"), norte, quadros de parâmetros/dados/imóvel com variáveis e bloco de RT com assinatura.
- Biblioteca em pasta configurável; "Salvar como modelo" grava cópia sem dados do imóvel + miniatura + modelo.json.
- Tabela de correspondência editável `dados/correspondencia_camadas.csv` (catálogo e nomes do plugin Uso do Solo + apelidos dos SHP do projeto modelo do Drive); reconhece "AREA_DO_IMOVEL", "ÁREA DO IMÓVEL", "AREADOIMOVEL", "00_AREA_DO_IMOVEL"...
- Leitura de documentos (`core/documentos.py`, `core/pdf_texto.py`): recibo SIGCAR/SICAR e certidão de matrícula; pypdf quando existe, leitor próprio quando não; município pelo código IBGE do CAR (`dados/municipios_ibge_go.csv`, 246 municípios).
- Interface (`ui/dialog.py`): abas Planta, IA e Configurações.

Testes (integração, dados fictícios): Uso do Solo A3 e A2 e Passivos A3 gerados em menos de 1 s cada; legenda, escala e norte vinculados; nomes da legenda no padrão; variáveis resolvidas; QPT e prévia em pasta com acento; os dois mapas de Passivos com mesma extensão e escala; biblioteca salva e reaberta. **Passaram.** Com dados reais (Cristalina): A3 em 3,6 s e A2 em 1,0 s pela API; 2,8 s pelo botão da janela.

Falha encontrada e corrigida: legenda da planta de Passivos desenhada com os nomes técnicos (o rótulo desenhado é o do símbolo, não o do nó). Corrigido e o teste passou a conferir o rótulo desenhado.

## Fase 7 - Robustez, Windows e empacotamento

- Caminhos com espaço e acento: testados em leitura, gravação e ZIP (pasta "Fazenda São José teste").
- Mensagens em português com a ação a tomar; log na aba "NorteAgro Layout IA" do painel de mensagens.
- Scripts `.cmd` revisados (Python ausente, versão fora de 3.10-3.13, falha de rede no pip).
- PDF de várias páginas pelo GDAL do QGIS (sem PyMuPDF); página inexistente bloqueada; foto inclinada retificada com `QTransform.quadToQuad` (teste: diferença média de cor 3/255 contra a original).
- `metadata.txt`: versão **0.9.0**, `experimental=True`, `qgisMinimumVersion=3.40`, `qgisMaximumVersion=3.99`, porque a definição de pronto não foi cumprida inteira.

Revisão de código independente (outro agente, sem acesso ao raciocínio): achou 3 riscos altos de vazamento e vários itens médios/baixos. Os altos e quase todos os médios foram corrigidos; um médio ficou por decisão (caminhos das camadas no QPT do pacote do imóvel). Lista em `VALIDACAO_v1.md`.

Incidente de processo: duas instalações de teste usaram um ZIP anterior porque o envio com o mesmo nome não sobrescreveu o arquivo; percebido pela inspeção do código instalado, passou-se a usar nomes únicos e conferir o conteúdo do ZIP antes de instalar.

## Resultado final dos testes

- Sem QGIS: 53 testes (`test_nucleo`, `test_postprocess`, `test_documentos`) - todos passaram.
- QGIS 3.44.10 Windows: 40/40 (`testes/resultado_integracao_windows_3_44.json`).
