# Norte Agro - Uso do Solo v3.9.4

Plugin para QGIS 3.44+ destinado a padronizar projetos de uso do solo, criar e organizar camadas, manter espelhos KML, padronizar dados existentes, calcular áreas e gerar o Quadro de Áreas com conferências de desenho.

## 1. Terminologia

- **ARQUIVO**: chave técnica imutável, sem acento e com `_`, por exemplo `AREA_DE_VEGETACAO`. É usada nos nomes SHP/QML/KML, propriedades, catálogo, reconhecimento, operações espaciais e regras de conferência.
- **Nome de exibição**: rótulo mostrado no QGIS, nas telas e na planilha, por exemplo `Área de Vegetação Nativa`.
- **Pasta da camada**: pasta física da camada. Camadas novas usam o nome de exibição sanitizado para Windows; camadas antigas mantêm a pasta real que já possuem.
- **Área bruta**: área desenhada na camada.
- **Área considerada**: área usada no Quadro de Áreas depois da limpeza e do recorte apenas em memória.

A lógica interna usa sempre o ARQUIVO. Nomes de exibição e nomes de pasta são somente rótulos.

## 2. Instalação

1. Abra o QGIS 3.44 ou superior.
2. Vá em **Complementos > Gerenciar e instalar complementos > Instalar a partir do ZIP**.
3. Escolha o ZIP da v3.8.1.
4. Use o único acesso **Complementos > Norte Agro > Uso do Solo** ou o único ícone do plugin na barra.

## 3. Tela inicial

O plugin oferece três fluxos:

1. **Criar / gerenciar camadas** - cria ou usa a estrutura do mapa e gerencia as camadas.
2. **Criar camadas em uma pasta** - cria camadas do catálogo em uma pasta escolhida sem alterar a Pasta atual do projeto.
3. **Só calcular áreas** - calcula as camadas abertas e gera a planilha sem criar pastas.

## 4. Reconhecimento de nomes

O reconhecimento do cálculo segue esta ordem:

1. referência;
2. propriedade `norteagro/arquivo`;
3. mapeamento manual `norteagro_apelidos`;
4. apelidos;
5. nome do SHP, pasta física e nome da camada contra ARQUIVO e nome de exibição;
6. semelhança.

O resultado é sempre um ARQUIVO.

A normalização trata acentos, espaços, prefixo `00_`, sufixos de cópia, palavras de ligação, letras repetidas, anos grudados, sinônimos de antropizada/suprimida/supressão, após/depois, APP/RL, barragem/barramento, nascente/nascentes, vegetação nativa/remanescente e total implícito por família.

Exemplos:

```text
reserva_legall                         -> RESERVA_LEGAL
appp                                   -> APP_TOTAL
area_consoolidada                      -> AREA_CONSOLIDADA
REMANESCENTE DE VEGETAÇÃO NATIVA       -> AREA_DE_VEGETACAO
ÁREA ANTROPIZADA                       -> AREA_SUPRIMIDA
APP ANTROPIZADA                        -> APP_SUPRIMIDA
SUPRESSÃO EM RESERVA LEGAL             -> RESERVA_SUPRIMIDA
SUPRESSÃO EM ÁREA PASSÍVEL             -> SUPRESSAO_PASSIVEL_TOTAL
```

### Apelidos do escritório

O arquivo `catalogo_extra.json` aceita:

```json
{
  "apelidos": {
    "NOME ANTIGO DA CAMADA": "AREA_DE_VEGETACAO"
  }
}
```

O destino precisa ser um ARQUIVO existente. A auditoria do catálogo detecta alias inválido e colisões depois da normalização.

Não é preciso editar o JSON: use a tela **Nomes não reconhecidos** (versão 0.1.1, abaixo).

## 5. Camadas de referência

Limites municipais, bases externas e serviços não entram no cálculo. A detecção considera tokens como MUNICIPIO, LIMITE, SICAR, SIGEF, INCRA e IBGE, a lista exata dos 246 municípios de Goiás, serviços web, camadas temporárias não reconhecidas como catálogo e extensão exageradamente maior que o imóvel.

Uma referência aparece em **Todas as camadas** e em **Conferências**, mas não entra no Quadro de Áreas.

## 6. Criar camadas em uma pasta

A tela permite montar uma lista de 1 a 50 linhas.

- O campo **Quantidade** e a lista permanecem sincronizados.
- **+ Adicionar camada** cria uma nova linha e move o foco para ela.
- O botão de remover de cada linha remove somente aquela linha.
- **Remover linhas vazias** limpa as linhas sem escolha.
- Enter avança para a próxima linha; na última cria outra. Ctrl+Enter executa Criar.
- A busca usa o mesmo reconhecimento e os mesmos apelidos do cálculo.
- Linhas repetidas são marcadas e bloqueiam a criação.
- Camada que já existe é pulada e nunca sobrescrita.

A pasta do KML é sugerida automaticamente:

1. se o destino estiver dentro do `shapefiles` da Pasta do Mapa, usa `<PASTA DO MAPA>\kml`;
2. senão, procura até 3 níveis acima por `kml` irmã de `shapefiles`;
3. senão, sugere `<PASTA DE DESTINO>\kml`.

Criar em uma pasta não altera `norteagro_pasta`, `norteagro_srid` nem `norteagro_extras`.

## 7. Estrutura criada no disco

Estrutura principal:

```text
<PASTA DO MAPA>/
├── kml/
├── layout/
├── plantas pdf/
├── projetos/
└── shapefiles/
```

Camada nova:

```text
<PASTA DO MAPA>/
├── shapefiles/
│   └── Área de Vegetação Nativa/
│       ├── AREA_DE_VEGETACAO.shp
│       ├── AREA_DE_VEGETACAO.shx
│       ├── AREA_DE_VEGETACAO.dbf
│       ├── AREA_DE_VEGETACAO.prj
│       ├── AREA_DE_VEGETACAO.cpg
│       └── AREA_DE_VEGETACAO.qml
└── kml/
    └── Área de Vegetação Nativa/
        └── AREA_DE_VEGETACAO.kml
```

A pasta usa o nome de exibição. Os arquivos usam o ARQUIVO.

### Projetos antigos

Formatos antigos continuam válidos, por exemplo:

```text
shapefiles/AREA_DE_VEGETACAO/AREA_DE_VEGETACAO.shp
```

O plugin usa a fonte física real da camada e não renomeia a pasta antiga.

### Migração do KML antigo

Se existir um KML solto em:

```text
kml/AREA_DE_VEGETACAO.kml
```

na primeira gravação ele é preservado em:

```text
kml/_antigos/AAAA-MM-DD/AREA_DE_VEGETACAO.kml
```

e o novo espelho passa a usar a subpasta física da camada.

## 8. Exportar KML

**Exportar KML** usa as camadas Norte Agro selecionadas no painel Layers. Se nenhuma estiver selecionada, exporta todas as identificadas pelo plugin.

Cada KML:

- usa EPSG:4326;
- mantém a simbologia;
- usa o ARQUIVO como nome;
- grava na subpasta correspondente à pasta física do SHP;
- sobrescreve somente o KML daquela camada;
- não é carregado no painel do QGIS.

Camadas avulsas usam `norteagro/kml_dir`.

## 9. Estabilidade do KML

O gerenciador KML guarda IDs de camadas, nunca objetos `QgsVectorLayer` entre ações. Antes de agir, busca a camada atual com `QgsProject.instance().mapLayer(id)`.

Também usa proteção para objetos destruídos e os sinais `layersWillBeRemoved`, `cleared` e `readProject`. No `unload()` os sinais são desconectados para evitar conexões duplicadas após recarregar o plugin.

## 10. Padronizar camadas

Na tela de cálculo, camadas sem `norteagro/arquivo` podem usar:

- **Criar camada padrão com este conteúdo**;
- **Remover camada**.

Também existe **Padronizar todas as reconhecidas** com prévia antes da execução.

Padronizar nunca renomeia o SHP original. O plugin cria ou localiza a camada padrão, valida o tipo de geometria, reprojeta, opcionalmente corrige geometrias, ignora registros sem geometria na cópia, preenche `id` sequencial e usa o fluxo de substituição com `_backup` quando o destino já existe.

Depois da padronização, a original pode ser mantida, removida do projeto ou, quando interna, movida para `_apagados`.

Arquivos externos nunca são apagados ou movidos automaticamente.

## 11. Nomes de exibição

`catalogo.py` contém `NOMES_EXIBICAO`, que associa cada ARQUIVO ao nome oficial da Planilha de Padronização.

Exemplos:

```text
AREA_DO_IMOVEL      -> Área Total do Imóvel
AREA_DE_VEGETACAO   -> Área de Vegetação Nativa
BARRAGEM            -> Barramentos
NASCENTE            -> Nascentes
RESERVA_LEGAL       -> Área de Reserva Legal
```

**Ajustar nomes no QGIS** altera somente `layer.setName()` e guarda o nome anterior em `norteagro/nome_original`. **Voltar nomes de arquivo** restaura exatamente esse nome anterior. Nenhum dos dois comandos altera SHP, pasta, QML, KML ou `norteagro/arquivo`.

### Corrigir nomes pelo catálogo do escritório

`catalogo_extra.json` pode conter:

```json
{
  "nomes_exibicao": {
    "AREA_DE_VEGETACAO": "Área de Vegetação Nativa"
  }
}
```

O JSON tem prioridade. Camadas já existentes continuam na pasta física antiga; somente novas camadas passam a usar o novo nome de pasta.

## 12. Chaves do catalogo_extra.json

Formato compatível:

```json
{
  "extras": [],
  "ocultas": [],
  "removidas": [],
  "apelidos": {},
  "nomes_exibicao": {},
  "fechamento": [],
  "fechamento_inclui_hidrografia": false,
  "nao_recortar": []
}
```

A auditoria `verificar_catalogo()` verifica nomes repetidos, pastas repetidas, ARQUIVOs inexistentes nas regras, aliases inválidos, fechamento, estilos e demais referências técnicas.

## 13. Conferência de desenho

O cálculo nunca altera nenhuma camada nem arquivo. Toda limpeza, recorte, correção de geometria e densificação acontece somente em cópias temporárias do cálculo.

### Limpeza

- registros sem geometria são ignorados e registrados;
- geometrias inválidas são corrigidas apenas na cópia temporária e registradas;
- lascas menores que 1 m² continuam no cálculo, mas são marcadas para conferência;
- mesmo arquivo carregado mais de uma vez é contado uma única vez;
- KML do próprio espelho é ignorado quando o SHP correspondente está carregado.

### Recorte no imóvel

Com **Área Total do Imóvel**, polígonos do catálogo são recortados apenas em memória antes de entrar no Quadro de Áreas e nas regras de conferência. O resultado registra:

- Área bruta;
- Fora do imóvel;
- Área considerada.

Linhas e pontos não são recortados, mas trechos/pontos fora do imóvel são avisados.

A chave `nao_recortar` permite exceções explícitas.

### Método de área

No método elipsoidal, todas as geometrias do cálculo são densificadas em memória com vértices a cada 10 m antes da medição. O rodapé informa:

```text
método Elipsoidal (GRS80, vértices a cada 10 m)
```

No método Plano UTM não há densificação.

A aba Conferências mantém a linha de comparação com a área do imóvel sem densificar para o técnico confrontar com SIGEF e matrícula.

## 14. Fechamento do imóvel

`FECHAMENTO_PADRAO`:

```text
AREA_SUPRIMIDA_ANTES_2019
AREA_SUPRIMIDA_DEPOIS_2019
AREA_CONSOLIDADA
AREA_DE_VEGETACAO
```

Pode ser substituído pela chave `fechamento` do JSON.

`fechamento_inclui_hidrografia` começa em `false`.

O plugin calcula:

- união das classes;
- Área sem classificação;
- sobreposição entre cada par;
- Total;
- Área Total do Imóvel.

A linha **Área sem classificação** só aparece quando for maior ou igual a `0,0001 ha`. A linha **Diferença** só aparece no quadro quando `|Total - Imóvel| >= 0,0001 ha`. A conferência do fechamento é sempre registrada na aba Conferências.

## 15. Regras de consistência R1 a R9

O plugin compara geometrias já limpas, recortadas e densificadas:

- **R1**: Imóvel = Vegetação + Consolidada + Suprimida antes + Suprimida depois, mais Hidrografia quando configurado.
- **R2**: APP Total = APP Preservada + APP Consolidada + APP Suprimida antes + APP Suprimida depois.
- **R3**: APP Suprimida = APP Suprimida antes + APP Suprimida depois.
- **R4**: Área Suprimida antes = APP antes + RL suprimida antes + Passível antes.
- **R5**: Área Suprimida depois = APP depois + RL suprimida depois + Passível depois.
- **R6**: Área Suprimida = antes + depois.
- **R7**: Reserva Legal = Preservada + Consolidada + Suprimida.
- **R8**: Reserva Legal Suprimida = antes + depois.
- **R9**: Supressão em Área Passível = antes + depois.

Para cada regra de conjunto são conferidos: sem cobertura, partes fora do todo e sobreposição entre partes. Camada necessária ausente gera **SEM DADOS**.

## 16. Regras de posição P1 a P6

- **P1**: subclasses de APP dentro da APP Total.
- **P2**: Reserva Legal Suprimida dentro da Reserva Legal.
- **P3**: Supressão em Área Passível fora da APP Total e da Reserva Legal.
- **P4**: APP Preservada e Reserva Legal Preservada dentro da Vegetação Nativa.
- **P5**: Vegetação Nativa sem sobreposição com Consolidada e Áreas Suprimidas.
- **P6**: Reserva Legal sobre Área Consolidada não é erro automático; sem Reserva Legal Consolidada, recebe **VERIFICAR**.

## 17. Formato dos problemas

Cada problema registra:

- regra;
- tipo e camadas envolvidas;
- tamanho;
- coordenadas E/N das maiores partes relevantes;
- situação: OK, ALERTA, CONFERIR, VERIFICAR ou SEM DADOS;
- texto **Como resolver**.

Exemplos de orientação:

- sem cobertura: desenhar ou estender a classe correta;
- fora do todo/imóvel: recortar a parte pelo todo;
- sobreposição: escolher a classe correta e aplicar Diferença;
- nulos: localizar por `is_empty_or_null($geometry)` e apagar os registros manualmente;
- geometria inválida: Corrigir geometrias e substituir o conteúdo;
- lasca: conferir e apagar/mesclar se for resto de desenho.

O plugin não corrige o desenho automaticamente.

## 18. Camada Conferência de geometria

Depois do cálculo, quando solicitado, é criada uma camada temporária em memória no grupo **Conferência**. Ela contém os campos:

```text
tipo
regra
camada
area_m2
e
n
```

Ela é substituída no próximo cálculo, nunca salva em disco, não gera KML e não participa de novos cálculos.

## 19. Planilha Excel

A planilha possui:

1. **Quadro de Áreas**;
2. **Todas as camadas**;
3. **Conferências**.

### Quadro de Áreas

- usa sempre Área considerada;
- título dos quadros em verde-claro da identidade Norte Agro;
- total em negrito com borda superior;
- caixa **Observações** ao lado somente dos quadros com problema;
- até quatro problemas maiores no quadro e indicação para ver a aba Conferências quando houver mais;
- faixa de atenção no topo quando existirem ALERTA/CONFERIR;
- identificação do imóvel/projeto, data, método e SRC.

### Todas as camadas

Inclui Área bruta, Fora do imóvel, Área considerada e Registros sem geometria.

### Conferências

Colunas:

```text
Regra | Verificação | Valor A | Valor B | Diferença | Situação | Como resolver
```

As situações têm texto e cor suave.

### Impressão

- A4 paisagem;
- uma página de largura;
- margens estreitas;
- rodapé `Norte Agro - Uso do Solo` e número da página.

## 20. Interface

A v3.8 centraliza a identidade visual em `estilo.py`.

Paleta principal:

```text
grafite       #262621
off-white     #FAF9F5
verde-ação    #46741F
folha         #7DA63F
marrom        #6E5E4E
```

O QSS é aplicado somente aos diálogos do plugin. O tema global do QGIS nunca é modificado. No tema escuro, fundos e textos respeitam a paleta do QGIS e o verde é mantido nas ações principais.

Padrões da interface:

- cabeçalho com ícone, título e descrição;
- seções visuais sem caixas excessivas;
- rodapé com ação principal à direita;
- selos de situação com texto e cor;
- painel de pendências;
- progresso nas operações demoradas;
- caminhos longos encurtados visualmente com tooltip completo;
- tamanho e posição dos diálogos salvos em `QgsSettings`;
- apenas hífen nos textos visíveis, nunca travessão longo.

## 21. Segurança de dados

- o cálculo nunca regrava SHP/DBF/SHX/QML/KML;
- criação nunca sobrescreve camada existente;
- substituição cria backup;
- remoção interna move para `_apagados`, não apaga definitivamente;
- arquivos externos são apenas removidos do projeto quando necessário;
- nomes de exibição não alteram nomes técnicos nem pastas existentes;
- KML antigo é migrado para `_antigos` sem ser apagado.

## 22. Testes

`testes_reconhecimento.py` roda fora do QGIS e verifica o catálogo completo, aliases, municípios, total implícito, tokens críticos e casos reais de reconhecimento.

`testes_conferencia.py` deve ser executado no Console Python do QGIS 3.44 e monta camadas de memória para validar recorte, nulos, duplicidade, densificação, fechamento, sobreposição, regras de consistência e camada de conferência.

Os testes manuais para interface, temas, escala do Windows e integridade de arquivos estão em `TESTES_MANUAIS.txt`.

---

**Norte Agro - Uso do Solo v3.9.4**


## Correção 3.8.1

- A tela **Calcular áreas** agora preenche a árvore de camadas no próprio `__init__`, tanto no fluxo **Só calcular áreas** quanto no botão da tela de camadas.
- Depois do preenchimento, a tela atualiza o contador, o checkbox **Selecionar todos**, a coluna **Situação**, o painel de pendências e o estado do botão **Calcular e gerar planilha**.
- Foram revisadas as telas de camadas, criação em pasta, padronização e substituição; todas já populavam suas listas/combos durante a abertura.
- `testes_conferencia.py` inclui um teste de abertura de `TelaAreas` sem `exec_()`, conferindo uma linha por camada vetorial do projeto, exceto a camada temporária de conferência.


## Correção 3.9.0 - cálculo que fecha mesmo com problemas de desenho

### Área considerada x Área no quadro

- **Área considerada**: área desenhada, limpa e recortada no imóvel (como antes). É sobre ela que as regras R1-R9, P1-P6 e G1-G3 apontam os erros de desenho.
- **Área no quadro**: área considerada depois da **resolução topológica em memória**. É ela que vai para o Quadro de Áreas. Nenhuma camada ou arquivo é alterado.

### Resolução topológica (`topologia.py`)

Cada quadro é tratado como uma divisão do seu "todo", sem sobreposição:

```text
Área Total do Imóvel  -> Suprimida depois > Suprimida antes > Consolidada > Vegetação (+ Hidrografia primeiro, se configurada)
APP Total             -> APP Suprimida depois > APP Suprimida antes > APP Consolidada > APP Preservada
                         (APP Suprimida também recortada pela Área Suprimida do período)
Área de Reserva Legal -> RL Suprimida > RL Consolidada > RL Preservada
Área Suprimida (período) -> APP Suprimida (mesmo valor do quadro APP) > RL Suprimida > Supressão em Área Passível
Área Fora da RL e APP = Vegetação resolvida - (RL + APP Total)
```

- Onde duas classes se sobrepõem, a área fica com a primeira da lista (T1).
- Parte fora do todo é desconsiderada no quadro (T2).
- Frestas de desenho (área < 1 m² ou largura média < 0,5 m) são somadas à classe vizinha com maior divisa comum (T3).
- Lacunas reais continuam como linha **Área sem classificação** (T4).
- Todo ajuste aparece na aba Conferências com situação **AJUSTADO**, área, coordenadas e como corrigir, e na camada "Conferência de geometria" (tipo "Ajuste no quadro").
- Operações com snap-rounding de 1 mm (`QgsGeometryParameters.setGridSize`), sem microlascas nem falhas do GEOS.

### Outras correções

- Correção de geometria com o método **Structure** (o Linework abria buracos onde o anel se cruza). A aba Conferências mostra a variação de área causada pela correção.
- "Fora do imóvel" = área bruta - área considerada (antes contava duas vezes feições sobrepostas).
- Densificação de 10 m só na medição, parte por parte (evita o fechamento do QGIS por "access violation" e deixa o cálculo mais rápido).
- Arredondamento que fecha: valores gravados com 4 casas e resíduo distribuído pelo maior resto, então as linhas exibidas somam exatamente o Total e a área do imóvel.
- Tolerância única de 0,0001 ha em todas as conferências de totais.
- `atualizar_camada_conferencia`: `childCount()` inexistente fazia o segundo cálculo falhar.

### Planilha

- Ordem: à esquerda Áreas Totais do Imóvel, Áreas Remanescentes, APP, Área Hidrográfica; à direita Passivos ambientais, Área antropizada antes de 2019, Área antropizada após 2019, Compensação, Outras.
- Caixa de Observações dimensionada pelo texto, sem esticar a linha do título nem invadir o quadro seguinte.
- Faixa azul no topo quando houver ajuste topológico.
- Todas as camadas: Área bruta, Fora do imóvel, Área considerada, Ajuste topológico, Área no quadro (ha e m²).
- Conferências agrupadas por seção (R, T, P, G, reconhecimento), ordenadas por situação e com filtro.

### Configuração opcional no `catalogo_extra.json`

```json
{
  "prioridade_fechamento": ["AREA_SUPRIMIDA_DEPOIS_2019", "AREA_SUPRIMIDA_ANTES_2019", "AREA_CONSOLIDADA", "AREA_DE_VEGETACAO"],
  "prioridade_app": ["APP_ANTROPIZADA_APOS_2019", "APP_ANTROPIZADA_ANTES_2019", "APP_CONSOLIDADA", "APP_PRESERVADA"],
  "prioridade_reserva": ["RESERVA_SUPRIMIDA", "RESERVA_CONSOLIDADA", "RESERVA_PRESERVADA"],
  "prioridade_antropizada": ["RL", "PASSIVEL"],
  "largura_max_lasca_m": 0.5
}
```

### Testes

`testes_conferencia.executar()` roda os testes antigos e `executar_v39()` (lasca, lacuna real, laço de digitalização, fora sem dupla contagem, coerência APP/antropizadas, arredondamento e layout da planilha).

### Ajustes após o teste no projeto real (Fazenda São Joaquim)

- Reconhecimento por sentido: supressão + APP/RL/passível + período em qualquer ordem ("SUPRESSÃO APP APOS 2019") e os nomes longos dos KML do SIGA/SEMAD ("... ENTRE AS DATAS DE 22_07_2008 E 27_12_2019 ...", "... APÓS A DATA DE 27_12_2019 ...").
- KML com contagem desconhecida (-2) passa a ter as feições contadas e entra marcado na tela de cálculo.
- Camada cujo arquivo não existe no computador aparece com o selo "Arquivo não encontrado", fica desmarcada e é registrada na aba Conferências (A7).
- Quando a mesma classe está em SHP e no espelho KML, o SHP é usado; a cópia aparece em "Todas as camadas" como "duplicada, contada pela camada ...".
- Toda camada marcada aparece na aba "Todas as camadas" com o destino dela (no quadro, duplicada, referência ou arquivo não encontrado).
- Quadro de Áreas só com resultados: área do imóvel uma única vez (Total), títulos centralizados, quadros em pares alinhados. Avisos e problemas de desenho ficam na aba "Observações" (Quadro, Nº, Situação, Observação, Tamanho, Onde, Como resolver).
- Lascas só são somadas a uma classe quando estão dentro do "pai" dela (evita APP Suprimida fora da Área Suprimida do período).

## Correção 3.9.1

- Telas "Criar e gerenciar camadas" e "Calcular áreas": marcar uma camada marcava o grupo inteiro. O grupo usava o três-estados automático do Qt; ao marcar um filho, o grupo virava "parcial" e isso era tratado como clique no grupo. Agora o estado do grupo é calculado pelo plugin: marcar uma camada marca só ela, e clicar no grupo continua marcando ou desmarcando todas as camadas visíveis do grupo.
- Tela "Calcular áreas": a coluna da caixinha tinha 42 px e, com o recuo do grupo, a caixinha de cada camada ficava com 2 px (não dava para clicar). A coluna passou para 78 px.

## Correção 3.9.2

- Quadro sem nenhuma classe desenhada (ex.: projeto só com a Área Total do Imóvel): o plugin não gera mais um "Ajuste no quadro" com o imóvel inteiro. A área entra como "Área sem classificação" e a regra R correspondente registra SEM DADOS.
- Camada "Conferência de geometria": a legenda mostra só os tipos encontrados no cálculo (antes listava todas as categorias, mesmo vazias) e ganhou o tipo "Ajuste no quadro" (azul).
- Quando o novo cálculo não tem problemas, a camada de conferência anterior e o grupo "Conferência" vazio são removidos do painel.
- Revisão do código inteiro: nenhum nome indefinido e nenhum método inexistente no QGIS 3.44 / Qt; cenários testados: só imóvel, sem imóvel, classes parciais, camada vazia, só registros nulos, ponto, camada em EPSG:4326, só APP Total, Área Suprimida sem subclasses, nos dois métodos de cálculo.

## Correção 3.9.3

- Mensagem ao criar camadas: "Criadas: X. Carregadas: Y" parecia indicar que só Y camadas tinham sido carregadas. Agora diz "X camada(s) criada(s) e carregada(s) no projeto" e, separado, quantas já existiam na pasta e foram apenas carregadas, sem sobrescrever.
- O espelho KML de uma camada nova é gravado no primeiro salvamento de uma edição (camada vazia ainda não tem KML).

## Correção 3.9.4 - teste completo do plugin

Todas as funções foram testadas em projeto de teste separado e o cálculo foi comparado com as planilhas entregues da Fazenda Serra da Onça e da Fazenda Serra Grande.

### Defeitos corrigidos

- **Substituir conteúdo** não funcionava: a tela mostrava sempre "0 feições" e o botão Substituir dava erro do Python sem substituir nada; a opção "Remover a camada de origem" não existia de fato. Agora mede a área no SRC do mapa, substitui com backup, descarta registros sem geometria (informando quantos), atualiza o KML e remove a origem do projeto quando pedido.
- **KML de camadas criadas em outra pasta** (Criar camadas em uma pasta / padronizar sem pasta do mapa) ia para a pasta errada: ao recarregar o estilo (.qml), as propriedades da camada eram apagadas. O QML agora guarda só a aparência.
- **Renomear pasta** falhava com "Acesso negado": o QGIS mantinha os .shp/.dbf abertos em cache. O plugin agora fecha essas conexões antes de renomear e tenta por alguns segundos se o Google Drive ou o antivírus estiver segurando algum arquivo.
- **Camadas de compensação** ("Compensação por supressão em APP/reserva/área passível") eram lidas como camadas de supressão e somariam nos passivos. Agora nunca são confundidas.
- **Camada sem SRC ou com SRC trocado** (coordenadas UTM marcadas como EPSG:4326) tinha a área zerada sem aviso. O SRC é deduzido pelas coordenadas e a aba Conferências avisa (regra G4).
- **Reserva Legal relocada/proposta**: a RL suprimida fora da RL proposta era zerada no quadro. Agora entra no quadro e a regra P2 avisa a posição.
- Conferência "Área antropizada após 2019" podia acusar ALERTA falso por uma fresta somada à APP; corrigido.
- Backups no mesmo segundo não se sobrescrevem mais; mover para _apagados tenta por até 15 s.
- Tela "Substituir" e padronização: contagem real de feições em KML.

### Reconhecimento de nomes

- Nomes com palavras a mais ("hidrografia rio", "nascente gps", "reserva legal proposta") são sugeridos em amarelo (Semelhança) para conferir; nomes ambíguos ("area consolidada em app") não são sugeridos.
- Nomes que perderam acentos em e-mail/ZIP/DAI ("supresso_em_rea_passvel_aps_2019") são reconhecidos.
- Entre duas camadas do mesmo tipo, o arquivo com o nome exato do padrão tem preferência.
- Quadro Área Hidrográfica: "Barramento 1 - PARTE 1" quando o campo nome se repete.

### Comparação com planilhas entregues

- Serra da Onça: Reserva Legal, APP, Hidrografia, Barramento e Cacimbas idênticos. A planilha entregue somava 715,4525 ha para um imóvel de 706,3963 ha (vegetação sobreposta ~11 ha contada duas vezes); o plugin fecha em 706,3963 ha.
- Serra Grande: Área Suprimida, Consolidada, Reserva Legal, APP e Hidrografia idênticos. A planilha entregue somava 370,8454 ha para um imóvel de 342,8196 ha (vegetação sobreposta ~28 ha); o plugin fecha em 342,8196 ha.

### Testes

`testes_conferencia.executar()` agora inclui `_testar_casos_reais_v394` (compensação, nomes sem acento, RL relocada, camada sem SRC).

## Correção 3.9.5 - lista de camadas de referência do escritório

Camadas que são só consulta (fitofisionomia, unidade de conservação, uso restrito e outras) podem ser cadastradas uma vez para o escritório todo. Elas passam a aparecer como **Referência** no Calcular áreas e não entram no quadro.

### Onde está o botão

- Tela inicial do plugin: botão **+ Referências** no rodapé.
- Calcular áreas: botão **+ Referência**. Se uma camada estiver selecionada, o nome dela já vem preenchido; ao salvar, a lista de camadas é reconhecida de novo na hora. Escolher "Referência" na coluna de classe e clicar em "Salvar no escritório" também abre essa lista.
- Criar/gerenciar camadas e Criar camadas em uma pasta: menu **Ferramentas > + Camadas de referência...**.

### Como funciona

- Digite um nome ou parte dele (ex.: "Fitofisionomia") e clique em **+ Adicionar**. A tela mostra antes quais camadas do projeto aberto serão afetadas.
- A comparação ignora acentos, maiúsculas e palavras a mais: "Fitofisionomia" pega "Fitofisionomia florestal 2008" e "FITOFISIONOMIA_SAVANICA".
- A lista fica gravada no catálogo do escritório (drive G:), com autor e data, e vale para todos que usam o plugin. **Remover da lista** desfaz, com confirmação.

### Proteções

- Nomes genéricos que derrubariam camadas do quadro ("APP", "área", "reserva legal", "vegetação nativa" etc.) são recusados.
- Uma camada com nome exato do catálogo, ou já marcada pelo plugin, continua com a classe dela, mesmo que o nome também contenha uma palavra da lista.

## Correção 3.9.6 - camadas novas no quadro e modelos do escritório

### Camada com nome novo entra no Quadro de Áreas

Ao criar uma camada com um nome novo (Criar/gerenciar camadas > **Nova camada**, ou **Adicionar ao catálogo**), escolha no campo **No Quadro de Áreas** onde ela entra:

- **Áreas Totais do Imóvel**: vira uma classe de uso do solo e entra na soma que fecha com a Área Total do Imóvel. Onde ela se sobrepõe a uma classe padrão, a área fica com a classe padrão e a sobreposição aparece em Conferências (T1).
- **Passivos ambientais**, **Área Hidrográfica** ou **Área Total de Compensação**: vira uma linha a mais nesse quadro. A parte que já está em outra linha do mesmo quadro é descontada (sem contar duas vezes) e avisada (T1).
- **Outras camadas**: quadro próprio no fim, sem total (era o comportamento antigo).
- **Não entra no Quadro de Áreas**: só na aba Todas as camadas.

Linhas e pontos não têm área: ficam só em Todas as camadas. Para mudar depois, clique com o botão direito na camada em Criar/gerenciar camadas > **Lugar no Quadro de Áreas...**. Camadas personalizadas antigas, sem essa escolha, continuam em Outras camadas.

### Modelos do escritório (pastas, cores e tabela)

Abra em **Modelos** (tela inicial do plugin), **Ferramentas > Modelos** (Criar/gerenciar camadas e Criar camadas em uma pasta), **Modelos...** (Configurar pasta e Calcular áreas).

- **Estrutura de pastas**: modelos com nome, cada um com pastas e subpastas próprias (use / para subpasta, ex.: plantas pdf/assinadas), a lista de camadas que ele cria (do catálogo ou novas, com estilo, grupo e lugar no quadro) e um tema de cores opcional. Escolha o modelo em **Configurar pasta do mapa**; para um projeto já configurado use **Aplicar neste projeto** (nada existente é apagado ou sobrescrito). shapefiles, kml e projetos são sempre criadas, porque o plugin depende delas.
- **Temas de cores**: pinte as camadas no QGIS (cor única, categorizado, graduado...) e clique em **+ Novo tema com as cores do projeto**. Aplique depois em qualquer projeto (com confirmação) ou escolha o tema num modelo de pastas. Com duas camadas do mesmo tipo no projeto, vale a da pasta do mapa. Ao aplicar por um modelo, só as camadas da pasta do mapa mudam.
- **Tabela**: modelos com nome para a planilha. Permitem: quadros visíveis, ordem, lado (esquerda/direita) e título; nome de qualquer linha; fonte, tamanho e cores; título da planilha com {imovel}, {data}, {metodo} e {src}; logo; colunas extras de m² e % da Área Total do Imóvel. **Ver exemplo no Excel** mostra o resultado antes de salvar. Escolha o modelo em Calcular áreas > **Modelo da tabela** (o último usado fica lembrado). O modelo **Padrão Norte Agro** é a planilha de sempre, idêntica à da versão 3.9.5.

Os modelos ficam em `modelos_norteagro.json`, ao lado do catálogo do escritório, num arquivo próprio: versões antigas do plugin que gravam no catálogo não conseguem apagá-los. Se esse arquivo estiver ilegível, o plugin não grava por cima. Os modelos "Padrão Norte Agro" são fixos; use **Duplicar** para criar os seus.

## Correção 3.9.7 - ajustes do teste completo

- **Criar camadas em uma pasta**: a camada personalizada criada nesse modo (que não altera o projeto) agora guarda a própria definição (nome, tipo, grupo e lugar no Quadro de Áreas) e é reconhecida no Calcular áreas. Antes ficava sem reconhecimento.
- **Modelo de pastas com camada que saiu do catálogo**: o resumo avisa "Não estão mais no catálogo (não criadas)" em vez de pular em silêncio. A lista do modelo mostra "Não encontrada" na coluna Origem.
- **Temas de cores**: novo botão **Remover camada do tema** (o tema passa a mudar só as camadas que ficaram). **Atualizar com as cores do projeto** atualiza só as camadas que já estão no tema, sem trazer de volta as removidas.
- Teste completo de tudo que entrou nas versões 3.9.5 e 3.9.6, pelas telas, com catálogo e pastas temporários: 89 verificações.

## Correção 3.9.8 - um só item no menu e pastas/camadas no modelo

- O menu Complementos > Norte Agro volta a ter **um único item: Uso do Solo**. Referências e Modelos ficam dentro do plugin (botões **+ Referências** e **Modelos** na tela inicial, menu **Ferramentas**, Configurar pasta e Calcular áreas).
- **Modelo de pastas**: as pastas principais (como layout e plantas pdf) podem ser criadas, renomeadas (clique duas vezes) ou removidas, e também as subpastas (documentos/fotos). Só shapefiles, kml e projetos são obrigatórias. A nova prévia **Como vai ficar** mostra a árvore final, com a pasta de cada camada dentro de shapefiles.
- **Editar camada...** (ou clique duplo) muda nome, tipo (polígono, linha, ponto), grupo, estilo e lugar no quadro de uma camada nova do modelo. A lista "+ Do catálogo..." mostra o tipo de cada camada.

## Correção 3.9.9 - pastas kml e projetos opcionais

- No modelo de pastas, **shapefiles** é a única pasta obrigatória (é onde ficam as camadas). **kml** e **projetos** viraram opções do modelo:
  - **Pasta kml** desmarcada: não cria a pasta kml e não grava a cópia KML automática ao salvar, padronizar ou substituir uma camada. **Ferramentas > Exportar KML** continua funcionando quando você pedir (cria a pasta nessa hora). Camadas criadas em "Criar camadas em uma pasta" mantêm o KML delas.
  - **Pasta projetos** desmarcada: o projeto do QGIS (.qgz) é sugerido na própria pasta do mapa.
- O modelo **Padrão Norte Agro** continua com as duas ligadas (nada muda para quem não usa modelos).
- A escolha fica gravada no projeto ao configurar a pasta ou aplicar o modelo.

## Correção 3.9.10 - rodada completa de testes guardada no plugin

- Novo `testes_interface.py`: testa de ponta a ponta, pelas telas, tudo o que o plugin faz:
  - camada nova no quadro, nos três jeitos de criar;
  - cálculo e planilha;
  - modelos de pastas, temas de cores e modelos de tabela;
  - Configurar pasta, com e sem kml/projetos;
  - referências, trava de gravação e arquivo de modelos corrompido;
  - criar camadas, padronizar, substituir, criar e apagar grupo, renomear pasta e backups.

  Usa catálogo e pastas temporários e devolve o projeto aberto como estava. Também confere que o arquivo .qgz aberto não foi gravado. Para rodar no Terminal Python do QGIS:
  `from norteagro_uso_solo import testes_interface; testes_interface.executar()` (67 verificações), junto com `testes_reconhecimento.main()` e `testes_conferencia.executar()`.
- Corrigido: religar a cópia KML das camadas (ao abrir um projeto ou o plugin) marcava o projeto como alterado mesmo sem mudar nada, e o QGIS perguntava "salvar alterações?" ao fechar.
- Corrigido: a bateria de cálculo deixava o projeto aberto marcado como alterado.

## Correção 3.9.11 - tema de cores e tipo da camada

- O tema guarda o símbolo de cada tipo: ponto (forma, tamanho, cor), linha (cor, espessura, tracejado) e polígono (preenchimento, borda, transparência).
- Proteção nova: se num projeto a camada com o mesmo nome for de outro tipo (ex.: ponto em vez de polígono), o tema não aplica o estilo nela (ficaria invisível) e avisa o motivo.
- Rodada de testes de interface: 69 verificações.

## Correção 3.9.12 - ajuda dentro do plugin e cálculo mais rápido

### Ajuda (tutorial)

- Toda janela do plugin tem um **?**: um círculo verde no canto do cabeçalho e o **?** da barra de título do Windows. Os dois abrem a ajuda já no assunto daquela tela (na tela de Modelos, no assunto da aba aberta).
- A tela inicial tem o botão **? Ajuda**, que abre o tutorial do começo.
- O tutorial tem 22 assuntos: passo a passo de um projeto novo e cada tela e botão do plugin, explicados. A janela tem busca (ignora acentos) e links entre assuntos. Ela não trava o plugin: dá para ler e usar ao mesmo tempo.
- Arquivo: `tela_ajuda.py`.

### Desempenho

Medido no projeto real da Fazenda Serra da Onça (28 camadas, 57 mil vértices): o cálculo caiu de **6,2 s para 3,6 s** (Plano UTM) e de **6,8 s para 4,0 s** (Elipsoidal). Os valores do quadro ficaram idênticos.

- As frestas absorvidas pela classe vizinha são unidas de uma vez só, em vez de uma a uma. A escolha do vizinho é a mesma.
- O resultado de uma operação de geometria não é checado de novo quanto à validade (o GEOS já devolve válido).
- O plugin só reprojeta camadas que estão em outro SRC, só corrige polígonos com geometria inválida e só dissolve camadas com mais de uma feição.

Telas: tela inicial 2 ms, Criar/gerenciar 70 ms, Calcular áreas 150 ms (com reconhecimento), Modelos 100 ms. A planilha é gerada em cerca de 0,05 s.

### Outros

- Na tela inicial, o caminho da pasta atual tem uma linha própria (não é mais cortado pelos botões).
- Rodada de testes de interface: 74 verificações (inclui a ajuda).

## Versão 0.0.0 - modelos de pastas livres (várias pastas mãe)

- A numeração da versão recomeçou em 0.0.0 (vem depois da 3.9.12).
- Modelos > Estrutura de pastas: árvore livre. O topo é o **local escolhido ao criar a estrutura**; dentro dele, **+ Pasta mãe** cria quantas pastas mãe quiser e **+ Subpasta** cria dentro da pasta selecionada, sem limite de níveis. Uma linha liga cada pasta à de cima.
- Para criar várias de uma vez, separe os nomes com `;`; use `/` para criar uma dentro da outra (`CAR/2026`). Depois de + Subpasta a mesma pasta continua selecionada.
- **Renomear** (ou F2, ou clique duplo), **Remover pasta** (ou Delete; tira a pasta e as de dentro, só do modelo) e menu no botão direito.
- **Pasta do mapa aqui** escolhe onde ficam as camadas do QGIS (marcada em verde). A primeira pasta mãe criada já vem marcada.
- Saíram as opções "Pasta kml" e "Pasta projetos" e as pastas em cinza: `kml`, `projetos` e `shapefiles` são pastas comuns. `kml` dentro da pasta do mapa liga o KML automático; `projetos` vira o lugar sugerido do .qgz; `shapefiles` nasce sozinha com a primeira camada, se o modelo não tiver.
- **Novo** começa com a árvore vazia. O modelo Padrão Norte Agro continua com MAPA USO DO SOLO / shapefiles, kml, projetos, layout e plantas pdf.
- Configurar pasta do mapa: 1. Modelo, 2. Criar dentro de, 3. um campo de nome para cada pasta mãe (ex.: o nome da fazenda), 4. SRC. Os nomes ficam guardados no projeto e são usados por "Aplicar neste projeto".
- Formato do modelo: `formato_pastas: 2`, `pastas` (caminhos a partir do local) e `pasta_mapa`. Modelos antigos são convertidos sozinhos (a pasta do mapa vira a pasta mãe "MAPA USO DO SOLO" e as opções kml/projetos viram pastas).
- Ajuda (?): passo a passo de como criar um modelo do zero, com exemplo, em "15. Modelos: estrutura de pastas".
- Velocidade: a árvore é montada fora da tela e os ícones são reaproveitados (um modelo com 1.220 pastas abre em cerca de 0,1 s).
- Configurar pasta lembra os nomes digitados de cada modelo ao trocar de modelo e voltar. Quando as camadas ficam no próprio local, `kml`, `projetos` e `shapefiles` desse nível não viram campos de nome.
- Testes: `apontar_catalogo` (em `testes_interface.py`) aponta para o arquivo temporário todas as cópias do módulo catálogo que estiverem na memória, para nenhum teste gravar no catálogo real do escritório (mesmo depois de recarregar o plugin sem reiniciar o QGIS). Novo teste E3: Configurar pasta com várias pastas mãe e nomes trocados. Rodada de interface: 85 verificações.

## Versão 0.1.1 - nomes não reconhecidos e catálogo sem Drive

### Tela "Nomes não reconhecidos"
- Onde: Calcular áreas > botão **Nomes não reconhecidos...** (já vem com a camada selecionada); botão **Ações** da camada > *Ensinar este nome*; Criar e gerenciar camadas > Ferramentas > *Nomes não reconhecidos (linha da tabela)*.
- Campo **Nome da camada**: o nome como vem (no QGIS ou no .shp). O botão *Camadas deste projeto* lista primeiro as não reconhecidas/incertas.
- Campo **Entra na tabela como**: a camada padrão, agrupada pelo quadro do Quadro de Áreas onde a linha aparece (Áreas Totais do Imóvel, Passivos ambientais, Áreas Remanescentes, Área antropizada antes/após 2019, APP, Área Hidrográfica, Compensação, Outras camadas, Usada nas contas, Só na aba Todas as camadas). Abaixo aparece o quadro e a linha.
- **Vale para**: todo o escritório (apelido no `catalogo_extra.json`) ou só este projeto (escolha manual gravada no .qgz para as camadas abertas com esse nome).
- Lista dos nomes já ensinados; dois cliques troca o destino; *Remover da lista*.
- Cadastrar de novo o mesmo nome (outra grafia) troca o destino em vez de dar conflito.
- Nomes ensinados (apelido do escritório e escolha do projeto) valem antes do filtro textual de referência (ex.: nomes com "Limite", "Município", "CAR").
- A coluna **Reconhecer como** de Calcular áreas usa a mesma lista agrupada por quadro.

### Erro "A pasta do catálogo do escritório está inacessível"
Acontecia quando o Google Drive (G:) não estava montado/acordado, estava em outra letra ou em inglês ("Shared drives"). Agora:
- o plugin procura a pasta ESTILOS em outras letras e nos dois idiomas, e espera alguns segundos o Drive acordar antes de desistir;
- sem acesso, a alteração (nome, referência, camada, cor...) é gravada em `<perfil do QGIS>/norteagro_uso_solo/catalogo_local.json` e já vale neste computador; quando o Drive volta, ela é enviada ao catálogo do escritório sozinha, somando com o que os outros mudaram (só o que mudou aqui é aplicado);
- a cópia local também guarda a última versão do catálogo vista, usada quando o Drive está fora (melhor que o padrão embutido);
- *Indicar a pasta do catálogo...* (aparece na tela Nomes não reconhecidos quando o Drive não é achado) grava o caminho neste computador (`norteagro_uso_solo/caminho_catalogo` nas configurações do QGIS). Também aceita a variável de ambiente `NORTEAGRO_CATALOGO`.
- Os testes que apontam o catálogo para uma pasta temporária nunca usam a cópia local.



## Versão 0.2.0 - tudo guardado dentro do plugin

- **Onde ficam os dados**: `<pasta do plugin>/dados/catalogo_extra.json` e `dados/modelos_norteagro.json`. A pasta `padrao/` é o de fábrica; `dados/` nasce dela na primeira abertura e recebe tudo o que é adicionado (nomes ensinados, referências, camadas catalogadas, cores padrão, modelos de pastas, temas de cores, modelos de tabela).
- **Atualizar sem perder nada**: cada gravação também copia o arquivo para `<perfil do QGIS>/norteagro_uso_solo/copia_dados/`. Reinstalar o ZIP apaga a pasta do plugin; na abertura seguinte o plugin restaura `dados/` dessa cópia.
- **Migração da 0.1.x** (só na primeira vez, se não houver cópia de segurança): lê o catálogo e os modelos do Drive (se acessível), soma as alterações que ficaram em `catalogo_local.json` e as cores guardadas nas configurações do QGIS.
- **Erro ao salvar/excluir modelo de pastas** corrigido: antes os modelos eram gravados no G: e, sem acesso, nada era gravado.
- **Sem avisos de Drive**: saiu o aviso vermelho e o botão *Indicar a pasta do catálogo...* da tela Nomes não reconhecidos.
- **Temas de cores com qualquer camada**: *+ Novo tema com as cores do projeto*, *Atualizar* e *Aplicar* usam todas as camadas vetoriais do projeto. Cada camada é guardada pela linha do catálogo que o plugin reconhece no nome (mesmo reconhecimento do Calcular áreas); a que não é reconhecida é guardada pelo próprio nome (`CAMADA:<nome>`).


## Versão 0.3.0 - Conferir e corrigir camadas antes de calcular

Módulos novos: `correcao.py` (motor) e `tela_correcao.py` (tela). Testes: `testes_correcao.py` (rodar no console do QGIS: `import norteagro_uso_solo.testes_correcao as t; print(t.executar())`).

Origem: engenharia reversa da ferramenta de sobreposição do app Bússola SIGCAR (`core/cross_layer_checks.py`, `core/layer_roles.py`, `core/geometry_checks.py`), adaptada às regras do Quadro de Áreas (`topologia.py`).

Fluxo: Calcular áreas > (opção "Conferir e corrigir as camadas antes de calcular", ligada por padrão) > `Correcao.executar()` em memória > tela com a lista do que será corrigido e, para cada sobreposição larga, "Quem cede a área?" > `executar(escolhas)` + `gravar()` (cópia em `_backup` ao lado de cada Shapefile/GeoPackage, edição com commit/rollback) > cálculo normal > `conferir_resultado()` confere que área do desenho = área do quadro em cada camada.

| Etapa | Regra |
|---|---|
| Geometria | registro sem geometria apagado; inválida corrigida (makeValid Structure); partes < 0,01 m² ou < 1 mm de largura apagadas; feição repetida apagada; feições da mesma camada sobrepostas: a repetição sai da de baixo |
| Fora do imóvel | tudo recortado no limite, menos `HIDRO_PODE_SAIR` (hidrografia, nascente, barragem, cacimba, tanque, lagoa, veredas, personalizadas HIDRO) e `nao_recortar`; feição inteira fora apagada; recorte > 1.000 m² em laranja |
| Quadros | Imóvel (fechamento), APP Total (subclasses, APP suprimida dentro da Área Suprimida do período), Reserva Legal, Área Suprimida do período (só a Passível cede), Área Hidrográfica (o rio cede para barramento/tanque/cacimba/lagoa), Compensação |
| Sobreposição | largura média (2·área/perímetro) < 1 m = faixa de traçado, sai da camada de menor prioridade; ≥ 1 m = conflito, o usuário escolhe quem cede (sugestão = prioridade) |
| Corte | `diferenca_robusta`: sem grade e com grade de 1 mm, fica com o que deixa menos sobra sobre a vencedora, até 4 voltas, sem fiapos |
| Frestas | < 1 m² ou largura < `largura_max_lasca_m` (0,5 m): somadas à feição vizinha de maior divisa; maiores = "sem classificação" (só aviso) |

O cálculo (`areas.py`) passou a tratar hidrografia fora do imóvel como permitida (situação OK, conta só a parte de dentro).
